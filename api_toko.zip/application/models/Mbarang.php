<?php
class Mbarang extends CI_Model 
{

}