<?php
defined('BASEPATH') or exit('No direct script access allowed');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

class Supplier extends CI_Controller
{
    public function index()
    {
        $data = $this->db->query("SELECT * FROM tbl_suplier")->result();
    
        $hasil = [
            'status' => 'ok',
            'data' => $data
        ];

        echo json_encode($hasil);
    }

    public function insert()
    {
        $suplier_nama = $_POST['suplier_nama'];
        $suplier_alamat = $_POST['suplier_alamat'];
        $suplier_notelp = $_POST['suplier_notelp'];

        $input = $this->db->query("INSERT INTO tbl_suplier (suplier_nama, suplier_alamat, suplier_notelp) VALUES ('$suplier_nama', '$suplier_alamat', '$suplier_notelp')");

        if ($input) {
            $hasil = [
                'status' => 'ok',
                'keterangan' => 'data berhasil ditambahkan'
            ];
        } else {
            $hasil = [
                'status' => 'gagal',
                'keterangan' => 'data gagal ditambahkan'
            ];
        }

        echo json_encode($hasil);
    }

    public function search()
    {
        $namaSupplier = $_POST['nama_supplier'];

        $data = $this->db->query("SELECT * FROM tbl_suplier WHERE suplier_nama LIKE '%$namaSupplier%'")->result();

        if (count($data) == 0) {
            $hasil = [
                'status' => 'not ok',
                'data' => NULL
            ];
        } else {
            $hasil = [
                'status' => 'ok',
                'data' => $data
            ];
        }

        echo json_encode($hasil);
    }

    public function update()
    {
        $suplier_id = $_POST['kodeSupplier']; 
        $suplier_nama = $_POST['suplier_nama'];
        $suplier_alamat = $_POST['suplier_alamat'];
        $suplier_notelp = $_POST['suplier_notelp'];

        $input = $this->db->query("UPDATE tbl_suplier SET suplier_nama = '$suplier_nama', suplier_alamat = '$suplier_alamat', suplier_notelp = '$suplier_notelp' WHERE suplier_id = $suplier_id");

        if ($input) {
            $hasil = [
                'status' => 'ok',
                'keterangan' => 'data berhasil diupdate'
            ];
        } else {
            $hasil = [
                'status' => 'gagal',
                'keterangan' => 'data gagal diupdate'
            ];
        }

        echo json_encode($hasil);
    }

    public function delete()
    {
        $suplier_id = $_POST['suplier_id'];

        $input = $this->db->query("DELETE FROM tbl_suplier WHERE suplier_id = $suplier_id");

        if ($input) {
            $hasil = [
                'status' => 'ok',
                'keterangan' => 'data berhasil dihapus'
            ];
        } else {
            $hasil = [
                'status' => 'gagal',
                'keterangan' => 'data gagal dihapus'
            ];
        }

        echo json_encode($hasil);
    }
}