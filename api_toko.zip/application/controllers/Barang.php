<?php
defined('BASEPATH') or exit('No direct script access allowed');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

class Barang extends CI_Controller
{
    public function index()
    {
        $data = $this->db->query("SELECT * FROM tbl_barang")->result();
    
        $hasil = [
            'status' => 'ok',
            'data' => $data
        ];

        echo json_encode($hasil);
    }

    public function insert()
    {
        // bingung dimana?
        // step 1
        // tangkap dlu input valnya, masukin ke variable

        // $_POST['nama_brg'] dapat dari input name di ajax
        // $nama_brg = $_POST['nama_brg'];
        $barang_nama = $_POST['barang_nama'];
        $barang_satuan = $_POST['barang_satuan'];
        $barang_harpok = $_POST['barang_harpok'];
        $barang_harjul = $_POST['barang_harjul'];
        $barang_harjul_grosir = $_POST['barang_harjul_grosir'];
        $barang_stok = $_POST['barang_stok'];
        $barang_min_stok = $_POST['barang_min_stok'];
        // gini?

        $input = $this->db->query("INSERT INTO tbl_barang 
            (barang_nama, barang_satuan, barang_harpok, barang_harjul, barang_harjul_grosir, barang_stok, barang_min_stok) 
            VALUES ('$barang_nama', '$barang_satuan', '$barang_harpok', '$barang_harjul', '$barang_harjul_grosir', '$barang_stok', '$barang_min_stok')");

        if ($input) {
            $hasil = [
                'status' => 'ok',
                'keterangan' => 'data berhasil ditambahkan'
            ];
        } else {
            $hasil = [
                'status' => 'gagal',
                'keterangan' => 'data gagal ditambahkan'
            ];
        }

        echo json_encode($hasil);

    }

    public function update()
    {
        $barang_id = $_POST['kodeBarang']; // ini kan lu nangkep barnag_id
        $barang_nama = $_POST['barang_nama'];
        $barang_satuan = $_POST['barang_satuan'];
        $barang_harpok = $_POST['barang_harpok'];
        $barang_harjul = $_POST['barang_harjul'];
        $barang_harjul_grosir = $_POST['barang_harjul_grosir'];
        $barang_stok = $_POST['barang_stok'];
        $barang_min_stok = $_POST['barang_min_stok'];

        $input = $this->db->query("UPDATE tbl_barang SET barang_nama = '$barang_nama', barang_satuan = '$barang_satuan', barang_harpok = '$barang_harpok', barang_harjul = '$barang_harjul', barang_harjul_grosir = '$barang_harjul_grosir', barang_stok = '$barang_stok', barang_min_stok = '$barang_min_stok' WHERE barang_id = $barang_id");

        if ($input) {
            $hasil = [
                'status' => 'ok',
                'keterangan' => 'data berhasil diupdate'
            ];
        } else {
            $hasil = [
                'status' => 'gagal',
                'keterangan' => 'data gagal diupdate'
            ];
        }

        echo json_encode($hasil);
    }

    public function search()
    {
        $namaBarang = $_POST['nama_barang'];

        $data = $this->db->query("SELECT * FROM tbl_barang WHERE barang_nama LIKE '%$namaBarang%'")->result();

        if (count($data) == 0) {
            $hasil = [
                'status' => 'not ok',
                'data' => NULL
            ];
        } else {
            $hasil = [
                'status' => 'ok',
                'data' => $data
            ];
        }

        echo json_encode($hasil);
    }

    public function delete()
    {
        $barang_id = $_POST['barang_id'];

        $input = $this->db->query("DELETE FROM tbl_barang WHERE barang_id = $barang_id");

        if ($input) {
            $hasil = [
                'status' => 'ok',
                'keterangan' => 'data berhasil dihapus'
            ];
        } else {
            $hasil = [
                'status' => 'gagal',
                'keterangan' => 'data gagal dihapus'
            ];
        }

        echo json_encode($hasil);
    }
}