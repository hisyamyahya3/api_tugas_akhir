<?php
defined('BASEPATH') or exit('No direct script access allowed');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

class Pelanggan extends CI_Controller
{
    public function index()
    {
        $data = $this->db->query("SELECT * FROM tbl_pelanggan")->result();
    
        $hasil = [
            'status' => 'ok',
            'data' => $data
        ];

        echo json_encode($hasil);
    }

    public function insert()
    {
        $pelanggan_nama = $_POST['pelanggan_nama'];
        $pelanggan_alamat = $_POST['pelanggan_alamat'];
        $pelanggan_notelp = $_POST['pelanggan_notelp'];

        $input = $this->db->query("INSERT INTO tbl_pelanggan (pelanggan_nama, pelanggan_alamat, pelanggan_notelp) VALUES ('$pelanggan_nama', '$pelanggan_alamat', '$pelanggan_notelp')");

        if ($input) {
            $hasil = [
                'status' => 'ok',
                'keterangan' => 'data berhasil ditambahkan'
            ];
        } else {
            $hasil = [
                'status' => 'gagal',
                'keterangan' => 'data gagal ditambahkan'
            ];
        }

        echo json_encode($hasil);
    }

    public function search()
    {
        $namaPelanggan = $_POST['nama_pelanggan'];

        $data = $this->db->query("SELECT * FROM tbl_pelanggan WHERE pelanggan_nama LIKE '%$namaPelanggan%'")->result();

        if (count($data) == 0) {
            $hasil = [
                'status' => 'not ok',
                'data' => NULL
            ];
        } else {
            $hasil = [
                'status' => 'ok',
                'data' => $data
            ];
        }

        echo json_encode($hasil);
    }

    public function update()
    {
        $pelanggan_id = $_POST['kodePelanggan']; 
        $pelanggan_nama = $_POST['pelanggan_nama'];
        $pelanggan_alamat = $_POST['pelanggan_alamat'];
        $pelanggan_notelp = $_POST['pelanggan_notelp'];

        $input = $this->db->query("UPDATE tbl_pelanggan SET pelanggan_nama = '$pelanggan_nama', pelanggan_alamat = '$pelanggan_alamat', pelanggan_notelp = '$pelanggan_notelp' WHERE pelanggan_id = $pelanggan_id");

        if ($input) {
            $hasil = [
                'status' => 'ok',
                'keterangan' => 'data berhasil diupdate'
            ];
        } else {
            $hasil = [
                'status' => 'gagal',
                'keterangan' => 'data gagal diupdate'
            ];
        }

        echo json_encode($hasil);
    }

    public function delete()
    {
        $pelanggan_id = $_POST['pelanggan_id'];

        $input = $this->db->query("DELETE FROM tbl_pelanggan WHERE pelanggan_id = $pelanggan_id");

        if ($input) {
            $hasil = [
                'status' => 'ok',
                'keterangan' => 'data berhasil dihapus'
            ];
        } else {
            $hasil = [
                'status' => 'gagal',
                'keterangan' => 'data gagal dihapus'
            ];
        }

        echo json_encode($hasil);
    }
}